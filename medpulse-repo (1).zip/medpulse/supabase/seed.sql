-- Sample data for the Chennai pilot. Phone numbers are PLACEHOLDERS: replace with real ones.
with h as (
  insert into public.hospitals (name, address, lat, lng, triage_phone, admin_phone, approved) values
    ('Apollo Greams Road', 'Greams Road, Chennai', 13.0604, 80.2530, '+914428290200', '+914428293333', true),
    ('Govt General Hospital', 'Park Town, Chennai', 13.0810, 80.2790, '+914425305000', '+914425305001', true),
    ('Kauvery Alwarpet', 'Alwarpet, Chennai', 13.0340, 80.2540, '+914440006000', '+914440006001', true),
    ('MIOT International', 'Manapakkam, Chennai', 13.0150, 80.1850, '+914442000000', '+914442000001', true)
  returning id, name
)
insert into public.resources (hospital_id, general, oxygen, icu, ventilator, ice_storage, antivenom, burn_kit)
select h.id, v.g, v.o, v.i, v.v, v.ice, v.av, v.bk
from h join (values
  ('Apollo Greams Road', 12, 6, 2, 1, true, true, true),
  ('Govt General Hospital', 30, 10, 0, 0, true, true, false),
  ('Kauvery Alwarpet', 5, 2, 4, 2, false, false, true),
  ('MIOT International', 18, 8, 3, 1, true, true, true)
) as v(n, g, o, i, v, ice, av, bk) on v.n = h.name;

insert into public.blood_stock (hospital_id, blood_group, units)
select h.id, g.grp, (abs(hashtext(h.name || g.grp)) % 9)
from public.hospitals h cross join (values ('A+'),('A-'),('B+'),('B-'),('AB+'),('AB-'),('O+'),('O-')) as g(grp);

insert into public.police_zones (name, control_room_phone, lat, lng, radius_km) values
  ('Chennai Traffic Control Room (placeholder)', '+919999999999', 13.0600, 80.2500, 8);
