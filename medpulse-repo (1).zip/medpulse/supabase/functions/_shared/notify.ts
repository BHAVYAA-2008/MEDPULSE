// Shared helpers for WhatsApp Cloud API and Fast2SMS.
// Every sender returns false (instead of throwing) when credentials are missing, so the
// whole flow can be tested in "dry run" mode before you finish Meta / DLT approvals.

export const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

export function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } })
}

const digits = (p: string) => {
  const d = (p || '').replace(/\D/g, '')
  return d.length === 10 ? '91' + d : d
}

export async function sendWhatsApp(to: string, template: string, params: string[], lang = 'en'): Promise<boolean> {
  const token = Deno.env.get('WHATSAPP_TOKEN')
  const phoneId = Deno.env.get('WHATSAPP_PHONE_ID')
  if (!token || !phoneId || !to) return false
  try {
    const r = await fetch(`https://graph.facebook.com/v20.0/${phoneId}/messages`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        to: digits(to),
        type: 'template',
        template: {
          name: template,
          language: { code: lang },
          components: [{ type: 'body', parameters: params.map((text) => ({ type: 'text', text })) }],
        },
      }),
    })
    return r.ok
  } catch {
    return false
  }
}

// Fast2SMS DLT route. Check the current Fast2SMS docs for the exact fields of your account.
export async function sendSMS(to: string, templateId: string | undefined, variables: string[]): Promise<boolean> {
  const key = Deno.env.get('FAST2SMS_KEY')
  const sender = Deno.env.get('FAST2SMS_SENDER')
  if (!key || !sender || !templateId || !to) return false
  try {
    const r = await fetch('https://www.fast2sms.com/dev/bulkV2', {
      method: 'POST',
      headers: { authorization: key, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        route: 'dlt',
        sender_id: sender,
        message: templateId,
        variables_values: variables.join('|'),
        numbers: digits(to).slice(-10),
        flash: 0,
      }),
    })
    return r.ok
  } catch {
    return false
  }
}

export function haversine(aLat: number, aLng: number, bLat: number, bLng: number) {
  const rad = (x: number) => (x * Math.PI) / 180
  const h =
    Math.sin(rad(bLat - aLat) / 2) ** 2 +
    Math.cos(rad(aLat)) * Math.cos(rad(bLat)) * Math.sin(rad(bLng - aLng) / 2) ** 2
  return 6371 * 2 * Math.asin(Math.sqrt(h))
}
