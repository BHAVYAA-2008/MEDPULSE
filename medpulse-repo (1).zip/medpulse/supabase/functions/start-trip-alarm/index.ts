// Driver starts a trip -> alarm goes to every traffic control room whose zone the route passes through.
// Body: { trip_id: string }
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { cors, haversine, json, sendSMS, sendWhatsApp } from '../_shared/notify.ts'

async function routePoints(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const base = Deno.env.get('OSRM_URL') ?? 'https://router.project-osrm.org'
  try {
    const r = await fetch(`${base}/route/v1/driving/${a.lng},${a.lat};${b.lng},${b.lat}?overview=full&geometries=geojson`)
    const j = await r.json()
    const coords: [number, number][] = j.routes?.[0]?.geometry?.coordinates ?? []
    // sample about every 20th point: enough to catch each zone the route crosses
    return coords.filter((_, i) => i % 20 === 0).map(([lng, lat]) => ({ lat, lng }))
  } catch {
    return []
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const url = Deno.env.get('SUPABASE_URL')!
    const userClient = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
    })
    const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)

    const { data: { user } } = await userClient.auth.getUser()
    if (!user) return json({ error: 'Login required' }, 401)

    const { trip_id } = await req.json()
    const { data: trip } = await admin
      .from('trips').select('*, hospitals(name, lat, lng)').eq('id', trip_id).maybeSingle()
    if (!trip || trip.driver_id !== user.id) return json({ error: 'Trip not found' }, 404)

    const start = { lat: trip.start_lat, lng: trip.start_lng }
    const dest = { lat: trip.hospitals.lat, lng: trip.hospitals.lng }
    const points = [start, ...(await routePoints(start, dest)), dest]

    const { data: zones } = await admin.from('police_zones').select('*')
    const hit = (zones ?? []).filter((z) => points.some((p) => haversine(p.lat, p.lng, z.lat, z.lng) <= z.radius_km))

    const trackUrl = `${Deno.env.get('APP_URL') ?? ''}/#/track/${trip.share_token}`
    const params = [trip.priority, trip.hospitals.name, String(trip.eta_minutes ?? '?'), trackUrl]
    const results: { zone: string; channel: string }[] = []

    for (const z of hit) {
      let channel = 'logged-only'
      if (await sendWhatsApp(z.control_room_phone, Deno.env.get('WA_TEMPLATE_POLICE') ?? 'police_alarm', params)) channel = 'whatsapp'
      else if (await sendSMS(z.control_room_phone, Deno.env.get('SMS_TEMPLATE_POLICE'), params)) channel = 'sms'

      // Optional: forward to your own system (control-room software, voice-call provider, etc.)
      const hook = Deno.env.get('ALARM_WEBHOOK_URL')
      if (hook) {
        try {
          await fetch(hook, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ zone: z.name, priority: trip.priority, hospital: trip.hospitals.name, eta_minutes: trip.eta_minutes, track_url: trackUrl }),
          })
          channel += '+webhook'
        } catch { /* keep going */ }
      }
      await admin.from('alarms').insert({ trip_id, zone_id: z.id, channel, status: 'sent', detail: params.join(' | ') })
      results.push({ zone: z.name, channel })
    }
    if (!hit.length) {
      await admin.from('alarms').insert({ trip_id, channel: 'none', status: 'no-zone', detail: 'No police zone on route' })
    }
    return json({ zones: results })
  } catch (e) {
    return json({ error: String(e) }, 500)
  }
})
