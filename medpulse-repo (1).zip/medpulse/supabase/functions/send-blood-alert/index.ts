// Hospital staff -> alert eligible donors by WhatsApp (SMS fallback).
// Body: { request_id: string, radius_km?: number }
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { cors, json, sendSMS, sendWhatsApp } from '../_shared/notify.ts'

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const url = Deno.env.get('SUPABASE_URL')!
    const userClient = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: req.headers.get('Authorization') ?? '' } },
    })
    const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)

    const { data: { user } } = await userClient.auth.getUser()
    if (!user) return json({ error: 'Login required' }, 401)

    const { request_id, radius_km } = await req.json()
    const { data: br } = await admin
      .from('blood_requests').select('*, hospitals(name)').eq('id', request_id).maybeSingle()
    if (!br) return json({ error: 'Request not found' }, 404)

    const { data: staff } = await admin
      .from('hospital_staff').select('user_id')
      .eq('hospital_id', br.hospital_id).eq('user_id', user.id).maybeSingle()
    if (!staff) return json({ error: 'Only staff of this hospital can send alerts' }, 403)

    const radius = Math.min(Number(radius_km) || br.radius_km, 25)
    if (radius !== br.radius_km) await admin.from('blood_requests').update({ radius_km: radius }).eq('id', request_id)

    const { data: donors, error } = await admin.rpc('eligible_donors', { p_request: request_id, p_radius: radius })
    if (error) return json({ error: error.message }, 500)

    const hospital = br.hospitals?.name ?? 'Hospital'
    const params = [hospital, br.blood_group, String(br.units)]
    const alerted: string[] = []
    let whatsapp = 0, sms = 0, skipped = 0

    for (const d of donors ?? []) {
      let channel: string | null = null
      if (await sendWhatsApp(d.phone, Deno.env.get('WA_TEMPLATE_BLOOD') ?? 'blood_request', params)) {
        channel = 'whatsapp'; whatsapp++
      } else if (await sendSMS(d.phone, Deno.env.get('SMS_TEMPLATE_BLOOD'), params)) {
        channel = 'sms'; sms++
      } else {
        skipped++ // no provider configured: donor still sees the in-app pop-up
      }
      // The in-app pop-up (Realtime) reaches the donor regardless of channel, so mark as alerted.
      await admin.from('donor_alerts').insert({ request_id, donor_id: d.id, channel: channel ?? 'in-app' })
      alerted.push(d.id)
    }
    if (alerted.length) await admin.rpc('bump_alert_count', { p_ids: alerted })

    return json({ eligible: donors?.length ?? 0, whatsapp, sms, in_app_only: skipped, radius_km: radius })
  } catch (e) {
    return json({ error: String(e) }, 500)
  }
})
