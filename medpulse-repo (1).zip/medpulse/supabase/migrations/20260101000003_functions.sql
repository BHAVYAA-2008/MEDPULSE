-- Business logic as database functions so every rule is enforced in one transaction.

-- Search hospitals by distance, resource type, blood group and quantity.
create or replace function public.search_hospitals(
  p_lat double precision, p_lng double precision,
  p_types text[] default '{}', p_group text default null, p_need int default 1)
returns table (
  id uuid, name text, address text, lat double precision, lng double precision,
  triage_phone text, admin_phone text, distance_km double precision,
  general int, oxygen int, icu int, ventilator int,
  ice_storage boolean, antivenom boolean, burn_kit boolean,
  blood_units int, updated_at timestamptz)
language sql stable as $$
  select h.id, h.name, h.address, h.lat, h.lng, h.triage_phone, h.admin_phone,
         public.haversine_km(p_lat, p_lng, h.lat, h.lng),
         r.general, r.oxygen, r.icu, r.ventilator, r.ice_storage, r.antivenom, r.burn_kit,
         coalesce(b.units, 0)::int, r.updated_at
  from hospitals h
  join resources r on r.hospital_id = h.id
  left join blood_stock b on b.hospital_id = h.id and b.blood_group = p_group
  where h.approved
    and (not ('general' = any(p_types)) or r.general >= p_need)
    and (not ('oxygen' = any(p_types)) or r.oxygen >= p_need)
    and (not ('icu' = any(p_types)) or r.icu >= p_need)
    and (not ('ventilator' = any(p_types)) or r.ventilator >= p_need)
    and (not ('ice_storage' = any(p_types)) or r.ice_storage)
    and (not ('antivenom' = any(p_types)) or r.antivenom)
    and (p_group is null or p_group = '' or coalesce(b.units, 0) >= p_need)
  order by public.haversine_km(p_lat, p_lng, h.lat, h.lng)
$$;

-- 15-minute bed hold. Decrements stock atomically so two people can never take the last bed.
create or replace function public.create_hold(p_hospital uuid, p_resource text)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid; n int;
begin
  if auth.uid() is null then raise exception 'Login required'; end if;
  if p_resource not in ('general','oxygen','icu','ventilator') then raise exception 'Invalid resource'; end if;
  if (select count(*) from holds where user_id = auth.uid() and status = 'active') >= 2 then
    raise exception 'You already have 2 active holds';
  end if;
  execute format(
    'update resources r set %I = %I - 1 where r.hospital_id = $1 and %I > 0 and exists (select 1 from hospitals h where h.id = r.hospital_id and h.approved)',
    p_resource, p_resource, p_resource) using p_hospital;
  get diagnostics n = row_count;
  if n = 0 then raise exception 'No units available'; end if;
  insert into holds(hospital_id, user_id, resource) values (p_hospital, auth.uid(), p_resource) returning id into v_id;
  return v_id;
end $$;

create or replace function public.release_hold(p_hold uuid)
returns void language plpgsql security definer set search_path = public as $$
declare v public.holds%rowtype;
begin
  select * into v from holds where id = p_hold and status = 'active';
  if v.id is null then return; end if;
  if v.user_id <> auth.uid() and not is_staff(v.hospital_id) then raise exception 'Not allowed'; end if;
  update holds set status = 'released' where id = v.id;
  execute format('update resources set %I = %I + 1 where hospital_id = $1', v.resource, v.resource) using v.hospital_id;
end $$;

create or replace function public.extend_hold(p_hold uuid)
returns void language plpgsql security definer set search_path = public as $$
declare v public.holds%rowtype;
begin
  select * into v from holds where id = p_hold and status = 'active';
  if v.id is null then return; end if;
  if not is_staff(v.hospital_id) then raise exception 'Only hospital staff can extend'; end if;
  update holds set expires_at = expires_at + interval '15 minutes' where id = v.id;
end $$;

-- Called by pg_cron every minute: expired holds go back into stock.
create or replace function public.release_expired_holds()
returns int language plpgsql security definer set search_path = public as $$
declare n int := 0; r record;
begin
  for r in update holds set status = 'expired' where status = 'active' and expires_at < now() returning hospital_id, resource loop
    execute format('update resources set %I = %I + 1 where hospital_id = $1', r.resource, r.resource) using r.hospital_id;
    n := n + 1;
  end loop;
  return n;
end $$;

-- Get or create the chat between the current user and a hospital.
create or replace function public.open_chat(p_hospital uuid, p_request uuid default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if auth.uid() is null then raise exception 'Login required'; end if;
  if not exists (select 1 from hospitals where id = p_hospital and approved) then raise exception 'Hospital not found'; end if;
  insert into chats(hospital_id, patient_id, request_id) values (p_hospital, auth.uid(), p_request)
  on conflict (hospital_id, patient_id) do update set request_id = coalesce(excluded.request_id, chats.request_id)
  returning id into v_id;
  return v_id;
end $$;

-- A matching donor ticks "I can donate": record it and open a chat with the hospital.
create or replace function public.contact_hospital(p_request uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_req public.blood_requests%rowtype; v_me public.profiles%rowtype; v_chat uuid;
begin
  select * into v_me from profiles where id = auth.uid();
  select * into v_req from blood_requests where id = p_request and status = 'open';
  if v_req.id is null then raise exception 'This request is closed'; end if;
  if not v_me.donor_opt_in or v_me.blood_group is distinct from v_req.blood_group then
    raise exception 'Your blood group does not match this request';
  end if;
  if v_me.last_donation is not null and v_me.last_donation > current_date - 90 then
    raise exception 'You donated recently. Please wait 90 days between donations';
  end if;
  insert into donor_responses(request_id, donor_id) values (p_request, auth.uid()) on conflict do nothing;
  v_chat := open_chat(v_req.hospital_id, p_request);
  insert into messages(chat_id, sender_id, body)
    values (v_chat, auth.uid(), 'I am a ' || v_me.blood_group || ' donor and can come now.');
  return v_chat;
end $$;

-- Donors who may be alerted: same group, consent, 90-day gap, under 2 alerts this week, in radius, not already alerted.
create or replace function public.eligible_donors(p_request uuid, p_radius int default 5)
returns table (id uuid, phone text, full_name text, distance_km double precision)
language sql security definer set search_path = public as $$
  select p.id, p.phone, p.full_name, public.haversine_km(h.lat, h.lng, p.lat, p.lng)
  from blood_requests br
  join hospitals h on h.id = br.hospital_id
  join profiles p on p.blood_group = br.blood_group
  where br.id = p_request and br.status = 'open'
    and p.donor_opt_in and p.lat is not null and p.lng is not null
    and (p.last_donation is null or p.last_donation <= current_date - 90)
    and p.alerts_this_week < 2
    and public.haversine_km(h.lat, h.lng, p.lat, p.lng) <= p_radius
    and not exists (select 1 from donor_alerts da where da.request_id = br.id and da.donor_id = p.id)
  order by 4
$$;

create or replace function public.bump_alert_count(p_ids uuid[])
returns void language sql security definer set search_path = public as $$
  update profiles set alerts_this_week = alerts_this_week + 1 where id = any(p_ids)
$$;

revoke all on function public.eligible_donors(uuid, int) from public, anon, authenticated;
revoke all on function public.bump_alert_count(uuid[]) from public, anon, authenticated;
revoke all on function public.release_expired_holds() from public, anon, authenticated;
grant execute on function public.eligible_donors(uuid, int) to service_role;
grant execute on function public.bump_alert_count(uuid[]) to service_role;
grant execute on function public.release_expired_holds() to service_role;

-- Family tracking link: anyone holding the secret token can see ONE trip, nothing else.
create or replace function public.get_trip_by_token(p_token uuid)
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'status', t.status, 'priority', t.priority, 'hospital_name', h.name,
    'hospital_lat', h.lat, 'hospital_lng', h.lng, 'eta_minutes', t.eta_minutes,
    'started_at', t.started_at, 'last_lat', lp.lat, 'last_lng', lp.lng, 'last_at', lp.at)
  from trips t
  join hospitals h on h.id = t.hospital_id
  left join lateral (select lat, lng, at from trip_points where trip_id = t.id order by at desc limit 1) lp on true
  where t.share_token = p_token
$$;
grant execute on function public.get_trip_by_token(uuid) to anon, authenticated;
