-- Row Level Security. Browsers only ever hold the anon key, so these rules ARE the security.

alter table public.profiles enable row level security;
alter table public.hospitals enable row level security;
alter table public.hospital_staff enable row level security;
alter table public.resources enable row level security;
alter table public.blood_stock enable row level security;
alter table public.holds enable row level security;
alter table public.blood_requests enable row level security;
alter table public.donor_alerts enable row level security;
alter table public.donor_responses enable row level security;
alter table public.chats enable row level security;
alter table public.messages enable row level security;
alter table public.trips enable row level security;
alter table public.trip_points enable row level security;
alter table public.police_zones enable row level security;
alter table public.alarms enable row level security;
alter table public.audit_log enable row level security;
-- police_zones, alarms, audit_log, donor_alerts: no policies = only the service role (Edge Functions) can use them.

-- profiles: read/update own row, and only safe columns (role can never be self-assigned)
create policy profiles_read_own on public.profiles for select using (id = auth.uid());
create policy profiles_update_own on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());
revoke update on public.profiles from authenticated, anon;
grant update (full_name, blood_group, last_donation, donor_opt_in, lat, lng, language) on public.profiles to authenticated;

-- hospitals, resources, blood stock: public read for approved hospitals, write for that hospital's staff
create policy hospitals_read on public.hospitals for select using (approved or is_staff(id));
create policy staff_read_own on public.hospital_staff for select using (user_id = auth.uid());

create policy resources_read on public.resources for select using (
  is_staff(hospital_id) or exists (select 1 from hospitals h where h.id = hospital_id and h.approved));
create policy resources_update on public.resources for update using (is_staff(hospital_id)) with check (is_staff(hospital_id));

create policy stock_read on public.blood_stock for select using (
  is_staff(hospital_id) or exists (select 1 from hospitals h where h.id = hospital_id and h.approved));
create policy stock_insert on public.blood_stock for insert with check (is_staff(hospital_id));
create policy stock_update on public.blood_stock for update using (is_staff(hospital_id)) with check (is_staff(hospital_id));

-- holds: created and released only through RPC functions; owners and staff can read
create policy holds_read on public.holds for select using (user_id = auth.uid() or is_staff(hospital_id));

-- blood requests: staff manage; only donors with the SAME blood group (and opted in) can see open requests
create policy requests_staff_read on public.blood_requests for select using (is_staff(hospital_id));
create policy requests_donor_read on public.blood_requests for select using (
  status = 'open' and exists (
    select 1 from profiles p
    where p.id = auth.uid() and p.donor_opt_in and p.blood_group = blood_requests.blood_group));
create policy requests_staff_insert on public.blood_requests for insert with check (is_staff(hospital_id) and created_by = auth.uid());
create policy requests_staff_update on public.blood_requests for update using (is_staff(hospital_id)) with check (is_staff(hospital_id));

-- donor responses: written through contact_hospital(); donors read their own
create policy responses_own on public.donor_responses for select using (donor_id = auth.uid());

-- chats and messages
create policy chats_read on public.chats for select using (patient_id = auth.uid() or is_staff(hospital_id));
create policy messages_read on public.messages for select using (can_access_chat(chat_id));
create policy messages_insert on public.messages for insert with check (sender_id = auth.uid() and can_access_chat(chat_id));

-- trips
create policy trips_read on public.trips for select using (driver_id = auth.uid() or is_staff(hospital_id));
create policy trips_insert on public.trips for insert with check (driver_id = auth.uid() and is_driver());
create policy trips_update on public.trips for update using (driver_id = auth.uid()) with check (driver_id = auth.uid());
create policy points_read on public.trip_points for select using (
  exists (select 1 from trips t where t.id = trip_id and (t.driver_id = auth.uid() or is_staff(t.hospital_id))));
create policy points_insert on public.trip_points for insert with check (
  exists (select 1 from trips t where t.id = trip_id and t.driver_id = auth.uid() and t.status = 'active'));

-- What hospital staff may see about donors who ticked "I can donate": name and group only, never phone.
create view public.hospital_donor_responses as
  select dr.request_id, dr.donor_id, p.full_name, p.blood_group, dr.created_at, br.hospital_id
  from donor_responses dr
  join profiles p on p.id = dr.donor_id
  join blood_requests br on br.id = dr.request_id
  where exists (select 1 from hospital_staff hs where hs.hospital_id = br.hospital_id and hs.user_id = auth.uid());
grant select on public.hospital_donor_responses to authenticated;
