-- MedPulse schema. Run migrations in order (or: supabase db push).

create table public.profiles (
  id uuid primary key references auth.users on delete cascade,
  role text not null default 'public' check (role in ('public','hospital_admin','driver')),
  full_name text,
  phone text,
  blood_group text check (blood_group in ('A+','A-','B+','B-','AB+','AB-','O+','O-')),
  last_donation date,
  donor_opt_in boolean not null default false,
  lat double precision,
  lng double precision,
  trust_score int not null default 50,
  alerts_this_week int not null default 0,
  language text not null default 'en',
  created_at timestamptz not null default now()
);

create table public.hospitals (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  address text,
  lat double precision not null,
  lng double precision not null,
  triage_phone text,
  admin_phone text,
  approved boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.hospital_staff (
  hospital_id uuid not null references public.hospitals on delete cascade,
  user_id uuid not null references public.profiles on delete cascade,
  primary key (hospital_id, user_id)
);

create table public.resources (
  hospital_id uuid primary key references public.hospitals on delete cascade,
  general int not null default 0 check (general >= 0),
  oxygen int not null default 0 check (oxygen >= 0),
  icu int not null default 0 check (icu >= 0),
  ventilator int not null default 0 check (ventilator >= 0),
  ice_storage boolean not null default false,
  antivenom boolean not null default false,
  burn_kit boolean not null default false,
  updated_at timestamptz not null default now()
);

create table public.blood_stock (
  hospital_id uuid not null references public.hospitals on delete cascade,
  blood_group text not null check (blood_group in ('A+','A-','B+','B-','AB+','AB-','O+','O-')),
  units int not null default 0 check (units >= 0),
  updated_at timestamptz not null default now(),
  primary key (hospital_id, blood_group)
);

create table public.holds (
  id uuid primary key default gen_random_uuid(),
  hospital_id uuid not null references public.hospitals on delete cascade,
  user_id uuid not null references public.profiles on delete cascade,
  resource text not null check (resource in ('general','oxygen','icu','ventilator')),
  status text not null default 'active' check (status in ('active','released','expired','used')),
  expires_at timestamptz not null default now() + interval '15 minutes',
  created_at timestamptz not null default now()
);

create table public.blood_requests (
  id uuid primary key default gen_random_uuid(),
  hospital_id uuid not null references public.hospitals on delete cascade,
  blood_group text not null check (blood_group in ('A+','A-','B+','B-','AB+','AB-','O+','O-')),
  units int not null default 1 check (units > 0),
  status text not null default 'open' check (status in ('open','fulfilled','cancelled','expired')),
  radius_km int not null default 5,
  created_by uuid references public.profiles,
  created_at timestamptz not null default now(),
  closed_at timestamptz
);

create table public.donor_alerts (
  request_id uuid not null references public.blood_requests on delete cascade,
  donor_id uuid not null references public.profiles on delete cascade,
  channel text,
  created_at timestamptz not null default now(),
  primary key (request_id, donor_id)
);

create table public.donor_responses (
  request_id uuid not null references public.blood_requests on delete cascade,
  donor_id uuid not null references public.profiles on delete cascade,
  confirmed boolean not null default true,
  created_at timestamptz not null default now(),
  primary key (request_id, donor_id)
);

create table public.chats (
  id uuid primary key default gen_random_uuid(),
  hospital_id uuid not null references public.hospitals on delete cascade,
  patient_id uuid not null references public.profiles on delete cascade,
  request_id uuid references public.blood_requests on delete set null,
  created_at timestamptz not null default now(),
  unique (hospital_id, patient_id)
);

create table public.messages (
  id bigserial primary key,
  chat_id uuid not null references public.chats on delete cascade,
  sender_id uuid not null references public.profiles on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now()
);

create table public.trips (
  id uuid primary key default gen_random_uuid(),
  driver_id uuid not null references public.profiles,
  hospital_id uuid not null references public.hospitals,
  priority text not null default 'Critical' check (priority in ('Critical','Serious','Stable')),
  status text not null default 'active' check (status in ('active','arrived','cancelled')),
  start_lat double precision,
  start_lng double precision,
  eta_minutes int,
  share_token uuid not null default gen_random_uuid(),
  started_at timestamptz not null default now(),
  ended_at timestamptz
);

create table public.trip_points (
  id bigserial primary key,
  trip_id uuid not null references public.trips on delete cascade,
  lat double precision not null,
  lng double precision not null,
  speed real,
  at timestamptz not null default now()
);
create index trip_points_trip_at on public.trip_points (trip_id, at desc);

create table public.police_zones (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  control_room_phone text,
  email text,
  lat double precision not null,
  lng double precision not null,
  radius_km double precision not null default 5
);

create table public.alarms (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references public.trips on delete cascade,
  zone_id uuid references public.police_zones,
  channel text,
  status text,
  detail text,
  sent_at timestamptz not null default now()
);

create table public.audit_log (
  id bigserial primary key,
  actor uuid,
  action text,
  target text,
  detail jsonb,
  at timestamptz not null default now()
);

-- Helpers -------------------------------------------------------------

create or replace function public.haversine_km(lat1 double precision, lon1 double precision, lat2 double precision, lon2 double precision)
returns double precision language sql immutable as $$
  select 6371 * 2 * asin(sqrt(
    power(sin(radians(lat2 - lat1) / 2), 2) +
    cos(radians(lat1)) * cos(radians(lat2)) * power(sin(radians(lon2 - lon1) / 2), 2)))
$$;

create or replace function public.is_staff(p_hospital uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from hospital_staff where hospital_id = p_hospital and user_id = auth.uid())
$$;

create or replace function public.is_driver()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'driver')
$$;

create or replace function public.can_access_chat(p_chat uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from chats c
    where c.id = p_chat and (c.patient_id = auth.uid() or is_staff(c.hospital_id)))
$$;

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

create or replace function public.log_change()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into audit_log(actor, action, target, detail) values (auth.uid(), tg_op, tg_table_name, to_jsonb(new));
  return new;
end $$;

create trigger resources_touch before update on public.resources for each row execute function public.touch_updated_at();
create trigger blood_stock_touch before update on public.blood_stock for each row execute function public.touch_updated_at();
create trigger resources_audit after update on public.resources for each row execute function public.log_change();
create trigger blood_stock_audit after insert or update on public.blood_stock for each row execute function public.log_change();

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into profiles(id, phone) values (new.id, new.phone) on conflict do nothing;
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();
