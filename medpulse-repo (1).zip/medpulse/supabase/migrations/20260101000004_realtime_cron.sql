-- Realtime: tables the app subscribes to.
do $$
declare t text;
begin
  foreach t in array array['resources','blood_stock','blood_requests','messages','trips','trip_points','holds'] loop
    begin
      execute format('alter publication supabase_realtime add table public.%I', t);
    exception when duplicate_object then null;
    end;
  end loop;
end $$;

-- Scheduled jobs (pg_cron). If your plan blocks this, enable pg_cron in Dashboard > Database > Extensions.
do $$
begin
  create extension if not exists pg_cron;
  perform cron.schedule('medpulse-release-holds', '* * * * *', 'select public.release_expired_holds()');
  perform cron.schedule('medpulse-reset-alerts', '0 0 * * 1', 'update public.profiles set alerts_this_week = 0');
  perform cron.schedule('medpulse-expire-requests', '*/10 * * * *',
    $q$update public.blood_requests set status = 'expired', closed_at = now() where status = 'open' and created_at < now() - interval '6 hours'$q$);
exception when others then
  raise notice 'pg_cron not set up: %', sqlerrm;
end $$;
