import { createContext, useCallback, useContext, useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

const Ctx = createContext(null)
export const useAuth = () => useContext(Ctx)

export function normalizePhone(p) {
  const d = String(p).replace(/\D/g, '')
  return d.length === 10 ? '+91' + d : '+' + d
}

export function AuthProvider({ children }) {
  const [session, setSession] = useState(null)
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)

  const loadProfile = useCallback(async (uid, retry = true) => {
    if (!uid) { setProfile(null); return }
    const { data } = await supabase.from('profiles').select('*').eq('id', uid).maybeSingle()
    if (!data && retry) { // the signup trigger may take a moment
      setTimeout(() => loadProfile(uid, false), 800)
      return
    }
    setProfile(data)
  }, [])

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session)
      loadProfile(data.session?.user.id).finally(() => setLoading(false))
    })
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s)
      loadProfile(s?.user.id)
    })
    return () => sub.subscription.unsubscribe()
  }, [loadProfile])

  const value = {
    session, profile, loading,
    sendOtp: (phone) => supabase.auth.signInWithOtp({ phone: normalizePhone(phone) }),
    verifyOtp: (phone, token) => supabase.auth.verifyOtp({ phone: normalizePhone(phone), token, type: 'sms' }),
    signOut: () => supabase.auth.signOut(),
    async updateProfile(patch) {
      const { error } = await supabase.from('profiles').update(patch).eq('id', session.user.id)
      if (!error) await loadProfile(session.user.id)
      return error
    },
  }
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}
