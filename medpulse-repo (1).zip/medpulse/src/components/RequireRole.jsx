import { Link, Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function RequireRole({ role, children }) {
  const { session, profile, loading } = useAuth()
  if (loading) return <p className="sub">Loading...</p>
  if (!session) return <Navigate to="/login" replace state={{ from: '/' }} />
  if (!profile) return <p className="sub">Loading your profile...</p>
  if (profile.role !== role) {
    return (
      <div className="card alert">
        <b>This portal needs an approved {role === 'driver' ? 'ambulance driver' : 'hospital admin'} account.</b>
        <p className="sub">
          Accounts are approved by the MedPulse team after verification. Share your registered mobile number with them to get access.
        </p>
        <Link className="btn" to="/patient">Go to patient portal</Link>
      </div>
    )
  }
  return children
}
