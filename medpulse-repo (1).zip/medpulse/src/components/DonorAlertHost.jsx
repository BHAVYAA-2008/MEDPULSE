import { useEffect, useRef, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { beep } from '../lib/beep'
import ChatModal from './ChatModal'

// Shows the "urgent blood request" pop-up.
// Row Level Security guarantees a user only ever receives requests that match their own blood group.
export default function DonorAlertHost() {
  const { session, profile } = useAuth()
  const [queue, setQueue] = useState([])
  const [ticked, setTicked] = useState(false)
  const [chat, setChat] = useState(null)
  const [err, setErr] = useState('')
  const seen = useRef(new Set())

  const eligible = !profile?.last_donation ||
    (Date.now() - new Date(profile.last_donation).getTime()) / 86400000 >= 90

  useEffect(() => {
    if (!session || !profile?.donor_opt_in || !profile?.blood_group) return
    const uid = session.user.id
    const sixHours = 6 * 3600 * 1000

    async function add(row) {
      if (row.created_by === uid || seen.current.has(row.id) || row.status !== 'open') return
      if (Date.now() - new Date(row.created_at).getTime() > sixHours) return
      seen.current.add(row.id)
      const { data: mine } = await supabase.from('donor_responses').select('request_id').eq('request_id', row.id).maybeSingle()
      if (mine) return
      const { data: h } = await supabase.from('hospitals').select('name').eq('id', row.hospital_id).maybeSingle()
      setQueue((q) => [...q, { ...row, hospital: h?.name || 'A hospital' }])
      beep()
    }

    supabase.from('blood_requests').select('*').eq('status', 'open').then(({ data }) => (data || []).forEach(add))
    const ch = supabase.channel('blood-alerts')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'blood_requests' }, (p) => add(p.new))
      .subscribe()
    return () => supabase.removeChannel(ch)
  }, [session, profile?.donor_opt_in, profile?.blood_group])

  const current = queue[0]
  const next = () => { setQueue((q) => q.slice(1)); setTicked(false); setErr('') }

  async function contact() {
    const { data, error } = await supabase.rpc('contact_hospital', { p_request: current.id })
    if (error) { setErr(error.message); return }
    setChat({ id: data, title: current.hospital })
    next()
  }

  if (chat) return <ChatModal chatId={chat.id} title={chat.title} onClose={() => setChat(null)} />
  if (!current) return null
  return (
    <div className="modal" role="alertdialog" aria-modal="true" aria-label="Urgent blood request">
      <div className="box">
        <h2 style={{ marginTop: 0, color: 'var(--red)' }}>Urgent blood request</h2>
        <p><b>{current.hospital}</b> needs <b>{current.blood_group}</b> blood, {current.units} unit(s).</p>
        <p className="ok">Your blood group {profile.blood_group} matches.</p>
        {eligible ? (
          <>
            <label>
              <input type="checkbox" checked={ticked} onChange={(e) => setTicked(e.target.checked)} />{' '}
              I confirm I can donate now (healthy, last donation more than 90 days ago)
            </label>
            {err && <p className="err">{err}</p>}
            <p>
              <button className="btn" disabled={!ticked} onClick={contact}>Contact hospital</button>{' '}
              <button className="btn y" onClick={next}>Not now</button>
            </p>
          </>
        ) : (
          <>
            <p className="no">You donated less than 90 days ago, so you cannot donate yet. Thank you for helping.</p>
            <button className="btn y" onClick={next}>Close</button>
          </>
        )}
      </div>
    </div>
  )
}
