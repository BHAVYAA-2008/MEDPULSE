import { Link, NavLink, Outlet } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import DonorAlertHost from './DonorAlertHost'

export default function Layout() {
  const { session, profile, signOut } = useAuth()
  const tabs = [['/patient', 'Patient portal'], ['/hospital', 'Hospital portal'], ['/ambulance', 'Ambulance portal']]
  return (
    <div className="wrap">
      <div className="bar">
        <Link to="/" style={{ textDecoration: 'none' }}><h1><span className="dot" />MedPulse</h1></Link>
        <span className="sub">
          {session ? (
            <>
              {profile?.blood_group ? `Blood group ${profile.blood_group}. ` : ''}
              <button className="btn y" onClick={signOut}>Sign out</button>
            </>
          ) : (
            <Link className="btn y" to="/login">Login</Link>
          )}
        </span>
      </div>
      <nav className="tabs" aria-label="Portals">
        {tabs.map(([to, label]) => (
          <NavLink key={to} to={to} className={({ isActive }) => 'tab' + (isActive ? ' active' : '')}>{label}</NavLink>
        ))}
      </nav>
      <Outlet />
      {session && <DonorAlertHost />}
    </div>
  )
}
