import { useEffect, useRef } from 'react'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'

// route: [[lat,lng],...]  dest/current: {lat,lng}
export default function MapView({ route = [], dest, current, height = 260 }) {
  const el = useRef(null)
  const map = useRef(null)
  const layer = useRef(null)
  const fitted = useRef(false)

  useEffect(() => {
    fitted.current = false
    map.current = L.map(el.current).setView([13.08, 80.27], 12)
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors',
    }).addTo(map.current)
    layer.current = L.layerGroup().addTo(map.current)
    return () => { map.current.remove(); map.current = null }
  }, [])

  useEffect(() => {
    const g = layer.current
    if (!g || !map.current) return
    g.clearLayers()
    const pts = []
    if (route.length) { L.polyline(route, { color: '#1d6fa5', weight: 5 }).addTo(g); pts.push(...route) }
    if (dest) { L.circleMarker([dest.lat, dest.lng], { radius: 9, color: '#1f9d6a', fillOpacity: 0.9 }).bindTooltip('Hospital').addTo(g); pts.push([dest.lat, dest.lng]) }
    if (current) { L.circleMarker([current.lat, current.lng], { radius: 9, color: '#d6453d', fillOpacity: 0.9 }).bindTooltip('Ambulance').addTo(g); pts.push([current.lat, current.lng]) }
    if (pts.length && !fitted.current) { map.current.fitBounds(pts, { padding: [30, 30] }); fitted.current = true }
  }, [route, dest, current])

  return <div ref={el} style={{ height, borderRadius: 14 }} role="img" aria-label="Map" />
}
