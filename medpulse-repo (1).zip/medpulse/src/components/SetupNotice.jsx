export default function SetupNotice() {
  return (
    <div className="wrap">
      <h1><span className="dot" />MedPulse</h1>
      <div className="card alert" style={{ marginTop: 16 }}>
        <b>Backend not connected yet</b>
        <p>
          Copy <code>.env.example</code> to <code>.env</code> and fill in <code>VITE_SUPABASE_URL</code> and{' '}
          <code>VITE_SUPABASE_ANON_KEY</code>. On Vercel or Netlify, add the same two variables in the project settings and redeploy.
          Full steps are in the README.
        </p>
        <p>Want to see the product first? The self-contained demo works with no backend:</p>
        <a className="btn" href="/demo.html">Open the demo</a>
      </div>
    </div>
  )
}
