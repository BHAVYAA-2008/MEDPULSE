import { useEffect, useRef, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'

export default function ChatModal({ chatId, title, onClose }) {
  const { session } = useAuth()
  const [msgs, setMsgs] = useState([])
  const [text, setText] = useState('')
  const end = useRef(null)

  useEffect(() => {
    let on = true
    supabase.from('messages').select('*').eq('chat_id', chatId).order('created_at')
      .then(({ data }) => on && setMsgs(data || []))
    const ch = supabase.channel('chat-' + chatId)
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: 'chat_id=eq.' + chatId },
        (p) => setMsgs((m) => (m.some((x) => x.id === p.new.id) ? m : [...m, p.new])))
      .subscribe()
    return () => { on = false; supabase.removeChannel(ch) }
  }, [chatId])

  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs])

  async function send(e) {
    e.preventDefault()
    const body = text.trim()
    if (!body) return
    setText('')
    await supabase.from('messages').insert({ chat_id: chatId, sender_id: session.user.id, body })
  }

  return (
    <div className="modal" role="dialog" aria-modal="true" aria-label={'Chat with ' + title}>
      <div className="box">
        <div className="row"><h2 style={{ margin: 0 }}>{title}</h2><button className="btn y" onClick={onClose}>Close</button></div>
        <div style={{ minHeight: 140, maxHeight: 280, overflow: 'auto', margin: '10px 0' }}>
          {msgs.length === 0 && <p className="sub">Ask about beds, oxygen or blood units.</p>}
          {msgs.map((m) => (
            <div key={m.id} className={'msg ' + (m.sender_id === session.user.id ? 'me' : 'them')}>{m.body}</div>
          ))}
          <div ref={end} />
        </div>
        <form onSubmit={send} className="row" style={{ flexWrap: 'nowrap' }}>
          <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message" aria-label="Message" />
          <button className="btn" type="submit">Send</button>
        </form>
      </div>
    </div>
  )
}
