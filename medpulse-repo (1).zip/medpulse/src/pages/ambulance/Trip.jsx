import { useCallback, useEffect, useRef, useState } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import { getPosition, haversine } from '../../lib/geo'
import { getRoute } from '../../lib/route'
import MapView from '../../components/MapView'

const PRIORITIES = ['Critical', 'Serious', 'Stable']

export default function Trip() {
  const { session } = useAuth()
  const uid = session.user.id
  const [hospitals, setHospitals] = useState([])
  const [dest, setDest] = useState(null)
  const [pri, setPri] = useState('Critical')
  const [trip, setTrip] = useState(null)
  const [hospital, setHospital] = useState(null)
  const [route, setRoute] = useState(null)
  const [cur, setCur] = useState(null)
  const [alarm, setAlarm] = useState(null)
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const [, tick] = useState(0)
  const watch = useRef(null)
  const lastSent = useRef(0)
  const wake = useRef(null)

  useEffect(() => {
    getPosition().then((p) =>
      supabase.rpc('search_hospitals', { p_lat: p.lat, p_lng: p.lng, p_types: [], p_group: null, p_need: 1 })
        .then(({ data }) => { setHospitals(data || []); if (data?.[0]) setDest(data[0].id) }))
    const t = setInterval(() => tick((n) => n + 1), 15000)
    return () => clearInterval(t)
  }, [])

  const stopTracking = useCallback(() => {
    if (watch.current != null) navigator.geolocation.clearWatch(watch.current)
    watch.current = null
    wake.current?.release?.().catch(() => {})
    wake.current = null
  }, [])

  const endTrip = useCallback(async (t, status = 'arrived') => {
    stopTracking()
    await supabase.from('trips').update({ status, ended_at: new Date().toISOString() }).eq('id', t.id)
    setTrip(null); setRoute(null); setCur(null); setAlarm(null)
  }, [stopTracking])

  const startTracking = useCallback(async (t, h) => {
    try { wake.current = await navigator.wakeLock?.request('screen') } catch { /* optional */ }
    watch.current = navigator.geolocation.watchPosition((p) => {
      const pt = { lat: p.coords.latitude, lng: p.coords.longitude }
      setCur(pt)
      if (haversine(pt, { lat: h.lat, lng: h.lng }) < 0.15) { endTrip(t); return }
      const now = Date.now()
      if (now - lastSent.current < 4000) return
      lastSent.current = now
      supabase.from('trip_points').insert({ trip_id: t.id, lat: pt.lat, lng: pt.lng, speed: p.coords.speed })
    }, (e) => setErr('GPS error: ' + e.message), { enableHighAccuracy: true, maximumAge: 2000 })
  }, [endTrip])

  // Resume a trip that is still active (for example after the page was reloaded)
  useEffect(() => {
    supabase.from('trips').select('*, hospitals(id,name,lat,lng)').eq('driver_id', uid).eq('status', 'active')
      .order('started_at', { ascending: false }).limit(1).maybeSingle().then(async ({ data }) => {
        if (!data) return
        setTrip(data); setHospital(data.hospitals)
        const p = await getPosition()
        const r = await getRoute(p, data.hospitals)
        if (r) setRoute(r.coords)
        startTracking(data, data.hospitals)
      })
    return stopTracking
  }, [uid, startTracking, stopTracking])

  async function start() {
    setErr(''); setBusy(true)
    const h = hospitals.find((x) => x.id === dest)
    const p = await getPosition()
    if (p.fallback) { setBusy(false); return setErr('Allow location access: live GPS is required to start a trip.') }
    const r = await getRoute(p, h)
    const { data: t, error } = await supabase.from('trips').insert({
      driver_id: uid, hospital_id: h.id, priority: pri,
      start_lat: p.lat, start_lng: p.lng, eta_minutes: r ? r.minutes : Math.ceil((haversine(p, h) / 30) * 60),
    }).select().single()
    if (error) { setBusy(false); return setErr(error.message) }
    setTrip(t); setHospital(h); setCur(p); if (r) setRoute(r.coords)
    startTracking(t, h)
    const { data: a, error: ae } = await supabase.functions.invoke('start-trip-alarm', { body: { trip_id: t.id } })
    setAlarm(ae ? { error: ae.message } : a)
    setBusy(false)
  }

  if (!trip) {
    return (
      <>
        <h2>Ambulance portal</h2>
        <div className="card">
          <p className="sub">Destination hospital</p>
          {hospitals.map((h) => (
            <button key={h.id} className={'chip' + (dest === h.id ? ' on' : '')} onClick={() => setDest(h.id)}>
              {h.name} ({h.distance_km.toFixed(1)} km, ICU {h.icu})
            </button>
          ))}
          <p className="sub">Patient priority</p>
          {PRIORITIES.map((p) => <button key={p} className={'chip' + (pri === p ? ' on' : '')} onClick={() => setPri(p)}>{p}</button>)}
          {err && <p className="err">{err}</p>}
          <p><button className="btn r" disabled={busy || !dest} onClick={start}>Start trip</button></p>
          <p className="sub">Starting a trip turns on live GPS and sends an alarm to the traffic police control room automatically.</p>
        </div>
      </>
    )
  }

  const eta = Math.max(0, trip.eta_minutes - Math.floor((Date.now() - new Date(trip.started_at).getTime()) / 60000))
  const link = `${location.origin}${location.pathname}#/track/${trip.share_token}`
  return (
    <>
      <h2>Trip to {hospital?.name}</h2>
      <div className="card">
        <div className="row"><b style={{ fontSize: 20 }}>ETA {eta} min</b><span className="sub">Hospital ER sees the same countdown</span></div>
        <MapView route={route || []} dest={hospital} current={cur} />
        {err && <p className="err">{err}</p>}
      </div>
      <div className="card alert">
        <b>Traffic police alarm</b>
        {!alarm && <p className="sub">Sending...</p>}
        {alarm?.error && <p className="err">{alarm.error}</p>}
        {alarm?.zones && (alarm.zones.length
          ? <ul className="sub">{alarm.zones.map((z) => <li key={z.zone}>{z.zone}: {z.channel}</li>)}</ul>
          : <p className="sub">No traffic control room is registered on this route.</p>)}
      </div>
      <div className="card">
        <b>Family tracking link</b>
        <p className="sub" style={{ wordBreak: 'break-all' }}>{link}</p>
        <a className="btn y" target="_blank" rel="noopener noreferrer" href={'https://wa.me/?text=' + encodeURIComponent('Live ambulance tracking: ' + link)}>Share on WhatsApp</a>
      </div>
      <button className="btn y" onClick={() => endTrip(trip)}>End trip</button>
    </>
  )
}
