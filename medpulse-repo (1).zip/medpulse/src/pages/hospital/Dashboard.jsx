import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import { BED_TYPES, GROUPS } from '../../lib/constants'
import { beep } from '../../lib/beep'
import ChatModal from '../../components/ChatModal'

export default function Dashboard() {
  const { session } = useAuth()
  const uid = session.user.id
  const [hosps, setHosps] = useState([])
  const [hid, setHid] = useState(null)
  const [res, setRes] = useState(null)
  const [stock, setStock] = useState({})
  const [reqs, setReqs] = useState([])
  const [donors, setDonors] = useState([])
  const [chats, setChats] = useState([])
  const [holds, setHolds] = useState([])
  const [trips, setTrips] = useState([])
  const [group, setGroup] = useState('AB-')
  const [units, setUnits] = useState(2)
  const [note, setNote] = useState('')
  const [chat, setChat] = useState(null)
  const [, tick] = useState(0)

  useEffect(() => {
    supabase.from('hospital_staff').select('hospital_id,hospitals(id,name)').eq('user_id', uid).then(({ data }) => {
      const list = (data || []).map((r) => r.hospitals)
      setHosps(list)
      if (list[0]) setHid(list[0].id)
    })
    const t = setInterval(() => tick((n) => n + 1), 1000)
    return () => clearInterval(t)
  }, [uid])

  const load = useCallback(async () => {
    if (!hid) return
    const [r, s, q, d, c, h, t] = await Promise.all([
      supabase.from('resources').select('*').eq('hospital_id', hid).maybeSingle(),
      supabase.from('blood_stock').select('*').eq('hospital_id', hid),
      supabase.from('blood_requests').select('*').eq('hospital_id', hid).eq('status', 'open').order('created_at', { ascending: false }),
      supabase.from('hospital_donor_responses').select('*').eq('hospital_id', hid),
      supabase.from('chats').select('id,patient_id,created_at').eq('hospital_id', hid),
      supabase.from('holds').select('id,resource,expires_at').eq('hospital_id', hid).eq('status', 'active'),
      supabase.from('trips').select('id,priority,eta_minutes,started_at').eq('hospital_id', hid).eq('status', 'active'),
    ])
    setRes(r.data)
    setStock(Object.fromEntries((s.data || []).map((x) => [x.blood_group, x.units])))
    setReqs(q.data || []); setDonors(d.data || []); setChats(c.data || []); setHolds(h.data || []); setTrips(t.data || [])
  }, [hid])

  useEffect(() => { load() }, [load])

  useEffect(() => {
    if (!hid) return
    const ch = supabase.channel('hospital-' + hid)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'holds', filter: 'hospital_id=eq.' + hid }, load)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'trips', filter: 'hospital_id=eq.' + hid }, (p) => { if (p.eventType === 'INSERT') beep(); load() })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chats', filter: 'hospital_id=eq.' + hid }, () => { beep(); load() })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, (p) => { if (p.new.sender_id !== uid) beep() })
      .subscribe()
    return () => supabase.removeChannel(ch)
  }, [hid, load, uid])

  async function bump(key, delta) {
    const v = Math.max(0, (res[key] || 0) + delta)
    setRes({ ...res, [key]: v })
    await supabase.from('resources').update({ [key]: v }).eq('hospital_id', hid)
  }
  async function flip(key) {
    const v = !res[key]
    setRes({ ...res, [key]: v })
    await supabase.from('resources').update({ [key]: v }).eq('hospital_id', hid)
  }
  async function bumpStock(g, delta) {
    const v = Math.max(0, (stock[g] || 0) + delta)
    setStock({ ...stock, [g]: v })
    await supabase.from('blood_stock').upsert({ hospital_id: hid, blood_group: g, units: v }, { onConflict: 'hospital_id,blood_group' })
  }

  async function requestBlood() {
    setNote('Sending...')
    const { data, error } = await supabase.from('blood_requests')
      .insert({ hospital_id: hid, blood_group: group, units, created_by: uid }).select().single()
    if (error) return setNote(error.message)
    await alertDonors(data.id)
    load()
  }
  async function alertDonors(id, radius) {
    const { data, error } = await supabase.functions.invoke('send-blood-alert', { body: { request_id: id, radius_km: radius } })
    if (error) return setNote('Request saved, but alerting failed: ' + error.message)
    setNote(`Alerted ${data.eligible} matching donors within ${data.radius_km} km (WhatsApp ${data.whatsapp}, SMS ${data.sms}, app pop-up only ${data.in_app_only}).`)
  }
  async function closeRequest(id) {
    await supabase.from('blood_requests').update({ status: 'fulfilled', closed_at: new Date().toISOString() }).eq('id', id)
    load()
  }
  async function holdAction(fn, id) { await supabase.rpc(fn, { p_hold: id }); load() }

  if (!hosps.length) return <div className="card alert">Your account is not linked to a hospital yet. Ask the MedPulse team to add you as staff.</div>
  if (!res) return <p className="sub">Loading...</p>

  const eta = (t) => Math.max(0, t.eta_minutes - Math.floor((Date.now() - new Date(t.started_at).getTime()) / 60000))
  const left = (h) => Math.max(0, Math.floor((new Date(h.expires_at) - Date.now()) / 1000))

  return (
    <>
      <h2>Hospital admin</h2>
      <select aria-label="Hospital" value={hid} onChange={(e) => setHid(e.target.value)}>
        {hosps.map((h) => <option key={h.id} value={h.id}>{h.name}</option>)}
      </select>

      {trips.map((t) => (
        <div className="card alert" key={t.id} style={{ marginTop: 10 }}>
          <b>Ambulance incoming</b> ({t.priority}) <b>ETA {eta(t)} min</b>
        </div>
      ))}

      <h2>Request blood</h2>
      <div className="card">
        <div className="row">
          <select aria-label="Blood group" style={{ flex: 1 }} value={group} onChange={(e) => setGroup(e.target.value)}>{GROUPS.map((g) => <option key={g}>{g}</option>)}</select>
          <input aria-label="Units" type="number" min="1" style={{ flex: 1 }} value={units} onChange={(e) => setUnits(Math.max(1, +e.target.value || 1))} />
        </div>
        <p className="sub">Only nearby users with the same blood group see this pop-up. They tick to confirm, then contact you.</p>
        <button className="btn r" onClick={requestBlood}>Send blood request</button>
        {note && <p className="sub">{note}</p>}
      </div>
      {reqs.map((r) => (
        <div className="card row" key={r.id}>
          <span><b>Open: {r.blood_group}</b>, {r.units} units, radius {r.radius_km} km</span>
          <span>
            <button className="btn y" onClick={() => alertDonors(r.id, 10)}>Widen to 10 km</button>{' '}
            <button className="btn" onClick={() => closeRequest(r.id)}>Mark fulfilled</button>
          </span>
        </div>
      ))}

      <h2>Donors who can come</h2>
      {donors.length === 0 && <div className="card sub">No donor response yet.</div>}
      {donors.map((d) => (
        <div className="card row" key={d.donor_id + d.request_id}>
          <span><b>{d.full_name || 'Donor'}</b> ({d.blood_group}) ticked: can donate</span>
        </div>
      ))}

      <h2>Patient and donor chats</h2>
      {chats.length === 0 && <div className="card sub">No messages yet.</div>}
      {chats.map((c) => (
        <div className="card row" key={c.id}>
          <span>Chat #{c.patient_id.slice(0, 4)}</span>
          <button className="btn" onClick={() => setChat({ id: c.id, title: 'Chat #' + c.patient_id.slice(0, 4) })}>Open</button>
        </div>
      ))}

      <h2>Held beds</h2>
      {holds.length === 0 && <div className="card sub">None.</div>}
      {holds.map((h) => (
        <div className="card row" key={h.id}>
          <span>{h.resource} held, {Math.floor(left(h) / 60)}:{String(left(h) % 60).padStart(2, '0')} left</span>
          <span>
            <button className="btn y" onClick={() => holdAction('extend_hold', h.id)}>Extend</button>{' '}
            <button className="btn y" onClick={() => holdAction('release_hold', h.id)}>Release</button>
          </span>
        </div>
      ))}

      <h2>Update inventory</h2>
      {BED_TYPES.map(([k, label]) => (
        <div className="card row" key={k}>
          <b>{label}s</b>
          <div className="cnt">
            <button aria-label={'Decrease ' + label} onClick={() => bump(k, -1)}>-</button>
            <b>{res[k]}</b>
            <button aria-label={'Increase ' + label} onClick={() => bump(k, 1)}>+</button>
          </div>
        </div>
      ))}
      {[['ice_storage', 'Ice storage'], ['antivenom', 'Snake venom antidote'], ['burn_kit', 'Burn care kits']].map(([k, label]) => (
        <div className="card row" key={k}>
          <b>{label}</b>
          <button className={'tog ' + (res[k] ? 'on' : 'off')} onClick={() => flip(k)}>{res[k] ? 'AVAILABLE' : 'OUT OF STOCK'}</button>
        </div>
      ))}

      <h2>Blood stock</h2>
      <div className="grid">
        {GROUPS.map((g) => (
          <div className="cell" key={g}>
            <b>{g}: {stock[g] || 0}</b>
            <div className="cnt" style={{ justifyContent: 'center' }}>
              <button aria-label={'Decrease ' + g} onClick={() => bumpStock(g, -1)}>-</button>
              <button aria-label={'Increase ' + g} onClick={() => bumpStock(g, 1)}>+</button>
            </div>
          </div>
        ))}
      </div>
      {chat && <ChatModal chatId={chat.id} title={chat.title} onClose={() => setChat(null)} />}
    </>
  )
}
