import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import MapView from '../components/MapView'

// Public page for family members: no login, only the secret link.
export default function FamilyTrack() {
  const { token } = useParams()
  const [t, setT] = useState(null)
  const [missing, setMissing] = useState(false)
  const [now, setNow] = useState(Date.now())

  useEffect(() => {
    let on = true
    async function load() {
      const { data } = await supabase.rpc('get_trip_by_token', { p_token: token })
      if (!on) return
      if (!data) setMissing(true); else setT(data)
    }
    load()
    const a = setInterval(load, 5000)
    const b = setInterval(() => setNow(Date.now()), 15000)
    return () => { on = false; clearInterval(a); clearInterval(b) }
  }, [token])

  const left = t ? Math.max(0, t.eta_minutes - Math.floor((now - new Date(t.started_at).getTime()) / 60000)) : 0
  return (
    <div className="wrap">
      <h1><span className="dot" />MedPulse live ambulance</h1>
      {missing && <div className="card alert">This tracking link is not valid.</div>}
      {t && (
        <div className="card">
          <div className="row">
            <b>To {t.hospital_name}</b>
            <b>{t.status === 'arrived' ? 'Arrived' : t.status === 'active' ? 'ETA ' + left + ' min' : t.status}</b>
          </div>
          <MapView dest={{ lat: t.hospital_lat, lng: t.hospital_lng }} current={t.last_lat ? { lat: t.last_lat, lng: t.last_lng } : null} />
          <p className="sub">Updates every 5 seconds. Priority: {t.priority}.</p>
        </div>
      )}
    </div>
  )
}
