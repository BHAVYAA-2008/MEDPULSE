import { Navigate, Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Home() {
  const { session, profile } = useAuth()
  if (session && profile) {
    const to = { hospital_admin: '/hospital', driver: '/ambulance' }[profile.role] || '/patient'
    return <Navigate to={to} replace />
  }
  return (
    <>
      <h2>Beds, blood and clear roads in the golden hour</h2>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))' }}>
        <div className="card"><b>Patient portal</b><p className="sub">Search beds, ICU, oxygen, ice storage, antidotes and blood. Chat with the hospital. Respond to blood requests.</p><Link className="btn" to="/patient">Open</Link></div>
        <div className="card"><b>Hospital portal</b><p className="sub">Update availability, request blood and talk to patients and donors.</p><Link className="btn" to="/hospital">Open</Link></div>
        <div className="card"><b>Ambulance portal</b><p className="sub">Start a trip. Traffic police are alarmed automatically.</p><Link className="btn" to="/ambulance">Open</Link></div>
      </div>
      {!session && <p><Link className="btn y" to="/login">Login with OTP</Link></p>}
    </>
  )
}
