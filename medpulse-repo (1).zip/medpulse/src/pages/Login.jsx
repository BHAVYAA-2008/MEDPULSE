import { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const { sendOtp, verifyOtp } = useAuth()
  const nav = useNavigate()
  const loc = useLocation()
  const [phone, setPhone] = useState('')
  const [code, setCode] = useState('')
  const [step, setStep] = useState(0)
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)

  async function send(e) {
    e.preventDefault()
    setErr('')
    if (phone.replace(/\D/g, '').length < 10) return setErr('Enter a 10-digit mobile number.')
    setBusy(true)
    const { error } = await sendOtp(phone)
    setBusy(false)
    if (error) return setErr(error.message)
    setStep(1)
  }

  async function verify(e) {
    e.preventDefault()
    setErr('')
    setBusy(true)
    const { error } = await verifyOtp(phone, code.trim())
    setBusy(false)
    if (error) return setErr('Wrong or expired code. ' + error.message)
    nav(loc.state?.from || '/', { replace: true })
  }

  return (
    <div className="card" style={{ maxWidth: 420 }}>
      <h2 style={{ marginTop: 0 }}>Verify your mobile</h2>
      <p className="sub">Browsing is free without login. Chat, bed hold, blood requests and trips need a verified number.</p>
      {step === 0 ? (
        <form onSubmit={send}>
          <label className="sub" htmlFor="ph">Mobile number</label>
          <input id="ph" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="10-digit mobile number" />
          {err && <p className="err">{err}</p>}
          <p><button className="btn" disabled={busy}>Send OTP</button></p>
        </form>
      ) : (
        <form onSubmit={verify}>
          <label className="sub" htmlFor="oc">6-digit code sent by SMS</label>
          <input id="oc" inputMode="numeric" value={code} onChange={(e) => setCode(e.target.value)} />
          {err && <p className="err">{err}</p>}
          <p><button className="btn" disabled={busy}>Verify and continue</button>{' '}
            <button type="button" className="btn y" onClick={() => setStep(0)}>Change number</button></p>
        </form>
      )}
    </div>
  )
}
