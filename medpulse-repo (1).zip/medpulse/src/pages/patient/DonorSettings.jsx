import { useState } from 'react'
import { useAuth } from '../../context/AuthContext'
import { GROUPS } from '../../lib/constants'
import { getPosition } from '../../lib/geo'

export default function DonorSettings() {
  const { profile, updateProfile } = useAuth()
  const [msg, setMsg] = useState('')
  if (!profile) return null

  async function save(patch) {
    const err = await updateProfile(patch)
    setMsg(err ? err.message : 'Saved')
  }
  async function useLocation() {
    const p = await getPosition()
    await save({ lat: p.lat, lng: p.lng })
    if (p.fallback) setMsg('Location permission denied. Saved the Chennai centre instead.')
  }

  return (
    <details className="card">
      <summary><b>My donor settings</b> <span className="sub">(so matching blood requests reach you)</span></summary>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit,minmax(180px,1fr))' }}>
        <div><span className="sub">Name</span>
          <input defaultValue={profile.full_name || ''} onBlur={(e) => save({ full_name: e.target.value })} /></div>
        <div><span className="sub">Blood group</span>
          <select value={profile.blood_group || ''} onChange={(e) => save({ blood_group: e.target.value || null })}>
            <option value="">Not set</option>{GROUPS.map((g) => <option key={g}>{g}</option>)}
          </select></div>
        <div><span className="sub">Last donation date</span>
          <input type="date" defaultValue={profile.last_donation || ''} onBlur={(e) => save({ last_donation: e.target.value || null })} /></div>
      </div>
      <label><input type="checkbox" checked={profile.donor_opt_in} onChange={(e) => save({ donor_opt_in: e.target.checked })} />{' '}
        I agree to receive urgent blood requests for my blood group (max 2 per week)</label>
      <p><button className="btn y" onClick={useLocation}>Use my current location</button>{' '}
        <span className="sub">{profile.lat ? 'Location saved.' : 'Location needed to find nearby requests.'}</span></p>
      {msg && <p className="sub">{msg}</p>}
    </details>
  )
}
