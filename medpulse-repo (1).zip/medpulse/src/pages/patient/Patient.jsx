import { useCallback, useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'
import { BED_TYPES, FACILITY_TYPES, GROUPS, STALE_MS } from '../../lib/constants'
import { getPosition } from '../../lib/geo'
import ChatModal from '../../components/ChatModal'
import DonorSettings from './DonorSettings'
import MyHolds from './MyHolds'

const ALL = [...BED_TYPES, ...FACILITY_TYPES]

export default function Patient() {
  const { session } = useAuth()
  const nav = useNavigate()
  const [types, setTypes] = useState([])
  const [group, setGroup] = useState('')
  const [need, setNeed] = useState(1)
  const [pos, setPos] = useState(null)
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState('')
  const [chat, setChat] = useState(null)
  const [holdKey, setHoldKey] = useState(0)
  const timer = useRef(null)

  useEffect(() => { getPosition().then(setPos) }, [])

  const load = useCallback(async () => {
    if (!pos) return
    setLoading(true)
    const { data, error } = await supabase.rpc('search_hospitals', {
      p_lat: pos.lat, p_lng: pos.lng, p_types: types, p_group: group || null, p_need: need,
    })
    setLoading(false)
    if (error) setErr(error.message); else { setErr(''); setRows(data || []) }
  }, [pos, types, group, need])

  useEffect(() => { load() }, [load])

  // Live updates: when any hospital changes stock, refresh (debounced).
  useEffect(() => {
    const refresh = () => { clearTimeout(timer.current); timer.current = setTimeout(load, 400) }
    const ch = supabase.channel('availability')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'resources' }, refresh)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'blood_stock' }, refresh)
      .subscribe()
    return () => { clearTimeout(timer.current); supabase.removeChannel(ch) }
  }, [load])

  const needLogin = () => {
    if (session) return false
    nav('/login', { state: { from: '/patient' } })
    return true
  }
  const toggle = (k) => setTypes((t) => (t.includes(k) ? t.filter((x) => x !== k) : [...t, k]))

  async function openChat(h) {
    if (needLogin()) return
    const { data, error } = await supabase.rpc('open_chat', { p_hospital: h.id })
    if (error) return setErr(error.message)
    setChat({ id: data, title: h.name })
  }
  async function hold(h, resource) {
    if (needLogin()) return
    const { error } = await supabase.rpc('create_hold', { p_hospital: h.id, p_resource: resource })
    if (error) setErr(error.message); else { setErr(''); setHoldKey((k) => k + 1); load() }
  }

  return (
    <>
      {session && <MyHolds refreshKey={holdKey} onChange={load} />}
      {session && <DonorSettings />}

      <h2>Search availability</h2>
      <div className="card">
        <p className="sub">What do you need?</p>
        {ALL.map(([k, label]) => (
          <button key={k} className={'chip' + (types.includes(k) ? ' on' : '')} aria-pressed={types.includes(k)} onClick={() => toggle(k)}>{label}</button>
        ))}
        <div className="row" style={{ alignItems: 'flex-end' }}>
          <div style={{ flex: 1, minWidth: 120 }}>
            <label className="sub" htmlFor="g">Blood group</label>
            <select id="g" value={group} onChange={(e) => setGroup(e.target.value)}>
              <option value="">Not needed</option>{GROUPS.map((g) => <option key={g}>{g}</option>)}
            </select>
          </div>
          <div style={{ flex: 1, minWidth: 120 }}>
            <label className="sub" htmlFor="n">How many units or beds</label>
            <input id="n" type="number" min="1" value={need} onChange={(e) => setNeed(Math.max(1, +e.target.value || 1))} />
          </div>
        </div>
        {pos?.fallback && <p className="sub">Location not shared, so distances are from central Chennai.</p>}
      </div>

      {err && <p className="err">{err}</p>}
      <h2>{loading ? 'Searching...' : `${rows.length} hospital${rows.length === 1 ? '' : 's'} match`}</h2>
      {!loading && rows.length === 0 && (
        <div className="card alert">Nothing matches. Lower the quantity, remove a filter, or call 108.</div>
      )}

      {rows.map((h) => {
        const stale = Date.now() - new Date(h.updated_at).getTime() > STALE_MS
        const mins = Math.max(0, Math.round((Date.now() - new Date(h.updated_at).getTime()) / 60000))
        return (
          <div className="card" key={h.id}>
            <div className="row">
              <div><b>{h.name}</b><div className="sub">{h.distance_km.toFixed(1)} km away</div></div>
              <span className={stale ? 'no' : 'sub'}>{stale ? 'Unconfirmed: ' : 'Updated '}{mins} min ago</span>
            </div>
            <div className="grid">
              {BED_TYPES.map(([k, label]) => (
                <div key={k} className={'cell' + (types.includes(k) ? ' hit' : '')}>
                  <b className={h[k] ? '' : 'no'}>{h[k]}</b><span className="sub">{label}</span>
                </div>
              ))}
              <div className={'cell' + (types.includes('ice_storage') ? ' hit' : '')}>
                <b className={h.ice_storage ? 'ok' : 'no'}>{h.ice_storage ? 'Yes' : 'No'}</b><span className="sub">Ice storage</span>
              </div>
              <div className={'cell' + (types.includes('antivenom') ? ' hit' : '')}>
                <b className={h.antivenom ? 'ok' : 'no'}>{h.antivenom ? 'Yes' : 'No'}</b><span className="sub">Antidote</span>
              </div>
              {group && (
                <div className="cell hit"><b className={h.blood_units ? '' : 'no'}>{h.blood_units}</b><span className="sub">Blood {group} units</span></div>
              )}
            </div>
            <button className="btn" onClick={() => openChat(h)}>Chat with hospital</button>{' '}
            {h.triage_phone && <a className="btn y" href={'tel:' + h.triage_phone}>Call</a>}{' '}
            <a className="btn y" target="_blank" rel="noopener noreferrer"
               href={'https://www.openstreetmap.org/directions?to=' + h.lat + ',' + h.lng}>Directions</a>
            <div style={{ marginTop: 6 }}>
              <span className="sub">Hold 15 min: </span>
              {BED_TYPES.filter(([k]) => h[k] > 0).map(([k, label]) => (
                <button key={k} className="chip" onClick={() => hold(h, k)}>{label}</button>
              ))}
            </div>
          </div>
        )
      })}
      {chat && <ChatModal chatId={chat.id} title={chat.title} onClose={() => setChat(null)} />}
    </>
  )
}
