import { useCallback, useEffect, useState } from 'react'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../context/AuthContext'

const LABEL = { general: 'General bed', oxygen: 'Oxygen bed', icu: 'ICU bed', ventilator: 'Ventilator' }

export default function MyHolds({ refreshKey, onChange }) {
  const { session } = useAuth()
  const [rows, setRows] = useState([])
  const [, tick] = useState(0)

  const load = useCallback(async () => {
    const { data } = await supabase.from('holds').select('id,resource,expires_at,hospitals(name)')
      .eq('user_id', session.user.id).eq('status', 'active')
    setRows(data || [])
  }, [session])

  useEffect(() => { load() }, [load, refreshKey])
  useEffect(() => { const t = setInterval(() => tick((n) => n + 1), 1000); return () => clearInterval(t) }, [])

  async function release(id) {
    await supabase.rpc('release_hold', { p_hold: id })
    load(); onChange?.()
  }

  const live = rows.filter((r) => new Date(r.expires_at) > new Date())
  if (!live.length) return null
  return live.map((r) => {
    const s = Math.max(0, Math.floor((new Date(r.expires_at) - Date.now()) / 1000))
    return (
      <div className="tok" key={r.id}>
        <span>{LABEL[r.resource]} held at {r.hospitals?.name}</span>
        <span><b>{Math.floor(s / 60)}:{String(s % 60).padStart(2, '0')}</b>{' '}
          <button className="btn y" onClick={() => release(r.id)}>Release</button></span>
      </div>
    )
  })
}
